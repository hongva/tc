<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

class WPBakeryShortCode_Rev_Slider_Vc extends WPBakeryShortCode {
}
